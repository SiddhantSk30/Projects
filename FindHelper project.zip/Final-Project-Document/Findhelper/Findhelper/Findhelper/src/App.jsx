import { useState } from 'react'





// import Header  from './Component/Header/Header'
// import Footer  from './Component/Footer/Footer'
// import Home from './Component/Home/Home/'
function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      
      
      
      {/*
     <Catagory/>
      <Team/>
      <Footer/>
      <SignIn/> 
        <Navbar />
        */}
    
      
    </>
  )
}

export default App
