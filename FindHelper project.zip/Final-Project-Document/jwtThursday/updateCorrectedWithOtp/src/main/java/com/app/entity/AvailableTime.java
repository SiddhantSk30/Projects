package com.app.entity;

public enum AvailableTime {
	MORNING,AFTERNOON,EVENING,NIGHT;
	
}
